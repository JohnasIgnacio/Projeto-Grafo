#ifndef FUNCOES_H
#define FUNCOES_H

#include "myTypesClion.h"

#define TAM_COD 4
#define TAM_CIDADE 50

typedef struct {
    U8 codigo[TAM_COD];
    U8 cidade[TAM_CIDADE];
} Aeroporto;

void inicializar();
void redimensionar();
I32 encontrarIndice(U8* codigo);
void cadastrarAeroporto();
void cadastrarVoo();
void removerVoo();
void listarVoos();
boolean buscaProfundidade(I32 origem, I32 destino, boolean* visitado);
void verificarTrajeto();
void menu();
void liberarMemoria();

#endif
