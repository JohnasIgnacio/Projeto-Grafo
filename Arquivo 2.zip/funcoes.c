#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"
#include "myTypesClion.h"

Aeroporto* aeroportos = NULL;
I32** matrizAdj = NULL;
I32 numAeroportos = 0;
I32 capacidade = 0;

void inicializar() {
    capacidade = 5;
    aeroportos = malloc(capacidade * sizeof(Aeroporto));
    matrizAdj = malloc(capacidade * sizeof(I32*));
    for (I32 i = 0; i < capacidade; i++) {
        matrizAdj[i] = calloc(capacidade, sizeof(I32));
    }

    U8* codigos[] = {"BSB", "CNF", "GIG", "GRU", "SSA"};
    U8* cidades[] = {"Brasilia", "Belo Horizonte", "Rio de Janeiro", "Guarulhos", "Salvador"};

    for (I32 i = 0; i < 5; i++) {
        strcpy((char*)aeroportos[i].codigo, (char*)codigos[i]);
        strcpy((char*)aeroportos[i].cidade, (char*)cidades[i]);
        numAeroportos++;
    }


    matrizAdj[0][4] = 107; // BSB -> SSA
    matrizAdj[1][2] = 555; // CNF -> GIG
    matrizAdj[1][3] = 101; // CNF -> GRU
    matrizAdj[1][4] = 214; // CNF -> SSA
    matrizAdj[2][1] = 554; // GIG -> CNF
    matrizAdj[2][3] = 90;  // GIG -> GRU
    matrizAdj[3][0] = 50;  // GRU -> BSB
    matrizAdj[3][1] = 102; // GRU -> CNF
    matrizAdj[3][2] = 89;  // GRU -> GIG
    matrizAdj[4][1] = 215; // SSA -> CNF
}


void redimensionar() {
    capacidade *= 2;
    aeroportos = realloc(aeroportos, capacidade * sizeof(Aeroporto));

    for (I32 i = 0; i < capacidade / 2; i++) {
        matrizAdj[i] = realloc(matrizAdj[i], capacidade * sizeof(I32));
        for (I32 j = capacidade / 2; j < capacidade; j++) {
            matrizAdj[i][j] = 0;
        }
    }

    matrizAdj = realloc(matrizAdj, capacidade * sizeof(I32*));
    for (I32 i = capacidade / 2; i < capacidade; i++) {
        matrizAdj[i] = calloc(capacidade, sizeof(I32));
    }
}

I32 encontrarIndice(U8* codigo) {
    for (I32 i = 0; i < numAeroportos; i++) {
        if (strcmp((char*)aeroportos[i].codigo, (char*)codigo) == 0)
            return i;
    }
    return -1;
}

void cadastrarAeroporto() {
    if (numAeroportos == capacidade) redimensionar();

    U8 codigo[TAM_COD], cidade[TAM_CIDADE];
    printf("Digite o código do aeroporto: ");
    scanf("%s", codigo);

    if (encontrarIndice(codigo) != -1) {
        printf("Aeroporto já cadastrado.\n");
        return;
    }

    printf("Digite o nome da cidade: ");
    scanf(" %[^\n]", cidade);

    strcpy((char*)aeroportos[numAeroportos].codigo, (char*)codigo);
    strcpy((char*)aeroportos[numAeroportos].cidade, (char*)cidade);
    numAeroportos++;
    printf("Aeroporto cadastrado com sucesso!\n");
}

void cadastrarVoo() {
    U8 origem[TAM_COD], destino[TAM_COD];
    I32 numero;

    printf("Digite o número do voo: ");
    scanf("%d", &numero);
    printf("Código do aeroporto de origem: ");
    scanf("%s", origem);
    printf("Código do aeroporto de destino: ");
    scanf("%s", destino);

    I32 i = encontrarIndice(origem);
    I32 j = encontrarIndice(destino);

    if (i == -1 || j == -1) {
        printf("Aeroporto não encontrado.\n");
        return;
    }

    if (matrizAdj[i][j] != 0) {
        printf("Já existe um voo nesta rota.\n");
        return;
    }

    matrizAdj[i][j] = numero;
    printf("Voo cadastrado com sucesso!\n");
}

void removerVoo() {
    I32 numero;
    printf("Digite o número do voo a remover: ");
    scanf("%d", &numero);

    for (I32 i = 0; i < numAeroportos; i++) {
        for (I32 j = 0; j < numAeroportos; j++) {
            if (matrizAdj[i][j] == numero) {
                matrizAdj[i][j] = 0;
                printf("Voo removido com sucesso!\n");
                return;
            }
        }
    }
    printf("Voo não encontrado.\n");
}

void listarVoos() {
    U8 origem[TAM_COD];
    printf("Digite o código do aeroporto de origem: ");
    scanf("%s", origem);

    I32 i = encontrarIndice(origem);
    if (i == -1) {
        printf("Aeroporto não encontrado.\n");
        return;
    }

    printf("\nVoos a partir de %s (%s):\n", aeroportos[i].cidade, aeroportos[i].codigo);
    boolean encontrou = false;

    for (I32 j = 0; j < numAeroportos; j++) {
        if (matrizAdj[i][j] != 0) {
            printf("  Voo %03d → %s (%s)\n", matrizAdj[i][j],
                   aeroportos[j].cidade, aeroportos[j].codigo);
            encontrou = true;
        }
    }

    if (!encontrou) {
        printf("  Nenhum voo registrado a partir deste aeroporto.\n");
    }
}


boolean buscaProfundidadeComCaminho(I32 origem, I32 destino, boolean* visitado, I32* caminho, I32* pos) {
    visitado[origem] = true;
    caminho[(*pos)++] = origem;

    if (origem == destino) return true;

    for (I32 i = 0; i < numAeroportos; i++) {
        if (matrizAdj[origem][i] != 0 && !visitado[i]) {
            if (buscaProfundidadeComCaminho(i, destino, visitado, caminho, pos)) {
                return true;
            }
        }
    }

    (*pos)--;
    return false;
}


void verificarTrajeto() {
    U8 origemCod[TAM_COD], destinoCod[TAM_COD];
    printf("Código do aeroporto de origem: ");
    scanf("%s", origemCod);
    printf("Código do aeroporto de destino: ");
    scanf("%s", destinoCod);

    I32 origem = encontrarIndice(origemCod);
    I32 destino = encontrarIndice(destinoCod);

    if (origem == -1 || destino == -1) {
        printf("Aeroporto não encontrado.\n");
        return;
    }

    boolean* visitado = calloc(numAeroportos, sizeof(boolean));
    I32* caminho = malloc(numAeroportos * sizeof(I32));
    I32 pos = 0;

    if (buscaProfundidadeComCaminho(origem, destino, visitado, caminho, &pos)) {
        printf("\nTrajeto encontrado:\n");
        for (I32 i = 0; i < pos - 1; i++) {
            I32 atual = caminho[i];
            I32 prox = caminho[i + 1];
            printf("  %s (%s) -- Voo %03d --> %s (%s)\n",
                   aeroportos[atual].cidade, aeroportos[atual].codigo,
                   matrizAdj[atual][prox],
                   aeroportos[prox].cidade, aeroportos[prox].codigo);
        }
    } else {
        printf("Não existe trajeto de %s para %s.\n", origemCod, destinoCod);
    }

    free(visitado);
    free(caminho);
}


void menu() {
    I32 opcao;
    do {
        printf("\n--- MENU MALHA AÉREA ---\n");
        printf("1. Cadastrar aeroporto\n");
        printf("2. Cadastrar voo\n");
        printf("3. Remover voo\n");
        printf("4. Listar voos de um aeroporto\n");
        printf("5. Verificar trajeto entre aeroportos\n");
        printf("0. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);
        switch (opcao) {
            case 1: cadastrarAeroporto(); break;
            case 2: cadastrarVoo(); break;
            case 3: removerVoo(); break;
            case 4: listarVoos(); break;
            case 5: verificarTrajeto(); break;
            case 0: printf("Encerrando...\n"); break;
            default: printf("Opção inválida.\n");
        }
    } while (opcao != 0);
}

void liberarMemoria() {
    for (I32 i = 0; i < capacidade; i++) {
        free(matrizAdj[i]);
    }
    free(matrizAdj);
    free(aeroportos);
}
