#include <stdio.h>
#include "funcoes.h"
#include "myTypesClion.h"

int main() {
    inicializar();
    menu();
    liberarMemoria();
    return 0;
}
